package com.cg.payroll.services;

import com.cg.payroll.bean.Associate;
import com.cg.payroll.bean.BankDetails;
import com.cg.payroll.bean.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;

public class PayrollServicesImpl {
	private PayrollDAOServicesImpl daoServices;
	public PayrollServicesImpl(){
		daoServices=new PayrollDAOServicesImpl();
	}
	public int acceptAssociateDetails(String firstName,String lastName,String department, String designation, String pancard,
			String emailId,int yearlyInvestmentUnder80C,double basicSalary,double epf, double companyPf,int accountNo,
			String bankName, String ifscCode){
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId,new Salary(basicSalary, epf, companyPf) , new BankDetails(accountNo, bankName, ifscCode)));
	}
	public double calculateNetSalary(int associateId){
		Associate associate=this.getAssociateDetails(associateId);
		if(associate!=null){
		associate.getSalary().setConveyenceAllowance((0.2*(associate.getSalary().getBasicSalary())));
		associate.getSalary().setPersonalAllowance  ((0.3*(associate.getSalary().getBasicSalary())));
		associate.getSalary().setOtherAllowance     ((0.1*(associate.getSalary().getBasicSalary())));
		associate.getSalary().setGratuity           ((0.05*(associate.getSalary().getBasicSalary())));
		associate.getSalary().setHra                ((0.25*(associate.getSalary().getBasicSalary())));
		associate.getSalary().setGrossSalary        (associate.getSalary().getBasicSalary()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getHra()+associate.getSalary().getCompanyPf());
		double annualGrossSalary   =12*associate.getSalary().getGrossSalary();
		double nonTaxable=(associate.getSalary().getEpf()+associate.getSalary().getCompanyPf())*12 +associate.getYearlyInvestmentUnder80C();
		double annualTax=0;
		if(nonTaxable>150000)
		nonTaxable=15000;
		if(annualGrossSalary<=250000)
		annualTax = 0;
		else if(annualGrossSalary>250000&&annualGrossSalary<=500000){
		if(annualGrossSalary-nonTaxable-250000>0)
		annualTax=.1*(annualGrossSalary-nonTaxable-250000);
		else
		annualTax = 0;
		}
		else if(annualGrossSalary>500000&&annualGrossSalary<=1000000)
		annualTax=.1*(-nonTaxable+250000)+.2*(annualGrossSalary-500000);
		else 
		annualTax=(.1*(-nonTaxable+250000))+(.2*500000)+.3*(annualGrossSalary-1000000);
		associate.getSalary().setMonthlyTax(annualTax/12);
		associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
		daoServices.updateAssociate(associate);
		return associate.getSalary().getNetSalary();
		}
		return 0;
	}
	public Associate getAssociateDetails(int associateID){
		return daoServices.getAssociate(associateID);
	}
	public Associate[] getAllAssociatesDetails(){
		return daoServices.getAssociates();
	}
}
