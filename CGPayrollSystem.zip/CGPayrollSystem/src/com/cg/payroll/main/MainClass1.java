package com.cg.payroll.main;

import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass1 {

	public static void main(String[] args) {
	PayrollServicesImpl payrollServices=new PayrollServicesImpl();
	int associateID= payrollServices.acceptAssociateDetails("Shishir", "Reddy", "jr con", "training", "asdf123", "shishir@gmail.com", 150000, 100000, 1000, 1000, 123456, "HDFC", "HDFC1234");
	System.out.println(associateID);
	//System.out.println(payrollServices.getAssociateDetails(associateID).toString());
    System.out.println(payrollServices.calculateNetSalary(associateID));
	System.out.println(payrollServices.getAssociateDetails(associateID).getSalary().getMonthlyTax());
	}
}
